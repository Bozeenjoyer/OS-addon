
# OS Addon Boze

OS Addon modules ported to the Boze Addon API for Minecraft 1.21.10.

Current modules:
- AnchorCity
- ArmorWarning
- AutoSponge
- FastBreak
- TNTAura

Use the `runBoze` task to run Boze. If you use `runClient`, the game will crash.
