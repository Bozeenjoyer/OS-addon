package com.example.addon.modules;

import dev.boze.api.addon.AddonModule;
import dev.boze.api.client.FriendManager;
import dev.boze.api.event.EventInteract;
import dev.boze.api.event.EventPlayerUpdate;
import dev.boze.api.event.EventShader;
import dev.boze.api.event.EventWorldRender;
import dev.boze.api.option.ColorOption;
import dev.boze.api.option.SliderOption;
import dev.boze.api.option.ToggleOption;
import dev.boze.api.render.ColorMaker;
import dev.boze.api.render.PlaceRenderer;
import dev.boze.api.render.WorldDrawer;
import dev.boze.api.utility.ChatHelper;
import dev.boze.api.utility.MathHelper;
import dev.boze.api.utility.WorldHelper;
import dev.boze.api.utility.interaction.Interaction;
import dev.boze.api.utility.interaction.InteractionMode;
import dev.boze.api.utility.interaction.InvHelper;
import dev.boze.api.utility.interaction.PlaceHelper;
import dev.boze.api.utility.interaction.SwapType;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class AnchorCity extends AddonModule {
    public static final AnchorCity INSTANCE = new AnchorCity();

    public final SliderOption targetRange = new SliderOption(this, "TargetRange", "How far away targets can be.", 5.5, 0.0, 8.0, 0.1);
    public final SliderOption breakRange = new SliderOption(this, "Range", "How far away the city block can be mined.", 4.8, 0.0, 6.0, 0.1);
    public final SliderOption breakDelay = new SliderOption(this, "BreakDelay", "Ticks between each mining attempt.", 0.0, 0.0, 10.0, 1.0);
    public final SliderOption placeDelay = new SliderOption(this, "PlaceDelay", "Ticks to wait before placing or interacting after a state change.", 0.0, 0.0, 10.0, 1.0);
    public final SliderOption charges = new SliderOption(this, "Charges", "How many glowstone charges to add before detonating.", 1.0, 1.0, 4.0, 1.0);
    public final ToggleOption instantRebreak = new ToggleOption(this, "InstantRebreak", "Immediately re-city the same surround spot when it is replaced.", true);
    public final ToggleOption airPlace = new ToggleOption(this, "AirPlace", "Allow anchor placement without direct support.", true);
    public final ToggleOption rotate = new ToggleOption(this, "Rotate", "Rotate before placing, charging, exploding and mining.", true);
    public final ToggleOption pauseOnEat = new ToggleOption(this, "PauseOnEat", "Pause while using an item.", true);
    public final ToggleOption silentSwitch = new ToggleOption(this, "SilentSwitch", "Use silent item swapping.", true);
    public final ToggleOption render = new ToggleOption(this, "Render", "Render the target, city block and anchor spot.", true);
    public final ToggleOption useShader = new ToggleOption(this, "UseShader", "Use Boze shader rendering for boxes.", true, render);
    public final ColorOption targetColor = new ColorOption(this, "TargetColor", "Color of the target player box.", ColorMaker.staticColor(255, 60, 60), 0.08f, 0.65f, render::getValue);
    public final ColorOption cityColor = new ColorOption(this, "CityColor", "Color of the surround block being mined.", ColorMaker.staticColor(255, 125, 45), 0.16f, 1.0f, render::getValue);
    public final ColorOption anchorColor = new ColorOption(this, "AnchorColor", "Color of the anchor placement and interaction spot.", ColorMaker.staticColor(90, 190, 255), 0.14f, 1.0f, render::getValue);

    private PlayerEntity target;
    private BlockPos breakPos;
    private BlockPos anchorPos;
    private Phase phase = Phase.Searching;
    private int breakTimer;
    private int interactTimer;
    private boolean warnedAboutDimension;
    private boolean placeQueued;
    private boolean chargeQueued;
    private boolean explodeQueued;

    private AnchorCity() {
        super("AnchorCity", "Cities a surround block, charges an anchor, detonates it and re-places it.");
    }

    @Override
    public void onEnable() {
        resetState();
    }

    @Override
    public void onDisable() {
        resetState();
    }

    @EventHandler
    private void onPlayerUpdate(EventPlayerUpdate event) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.getNetworkHandler() == null) return;

        placeQueued = false;
        chargeQueued = false;
        explodeQueued = false;

        if (pauseOnEat.getValue() && mc.player.isUsingItem()) return;

        if (mc.world.getDimension().respawnAnchorWorks()) {
            if (!warnedAboutDimension) {
                ChatHelper.sendMsg("anchor-city", "Respawn anchors do not explode in this dimension.");
                warnedAboutDimension = true;
            }
            return;
        }

        warnedAboutDimension = false;
        target = findTarget(mc);
        if (target == null) {
            resetTrackedBlocks();
            return;
        }

        if (InvHelper.findInHotbar(Items.RESPAWN_ANCHOR) == -1) {
            resetTrackedBlocks();
            return;
        }

        if (anchorPos == null || !isTrackedPosValid(target, anchorPos)) {
            anchorPos = findCityPos(mc, target);
        }

        if (anchorPos == null) {
            resetTrackedBlocks();
            return;
        }

        breakPos = anchorPos;
        BlockState state = mc.world.getBlockState(anchorPos);

        if (isSurroundBlock(state)) {
            phase = Phase.City;
            interactTimer = 0;
            if (instantRebreak.getValue() || breakTimer >= (int) Math.round(breakDelay.getValue())) {
                mineBlock(mc, breakPos);
                breakTimer = 0;
            } else {
                breakTimer++;
            }
            return;
        }

        breakTimer = 0;

        if (state.isReplaceable()) {
            phase = Phase.Place;
            if (interactTimer < (int) Math.round(placeDelay.getValue())) {
                interactTimer++;
                return;
            }

            placeQueued = true;
            return;
        }

        if (!state.isOf(Blocks.RESPAWN_ANCHOR)) {
            phase = Phase.Blocked;
            return;
        }

        if (interactTimer < (int) Math.round(placeDelay.getValue())) {
            interactTimer++;
            return;
        }

        int currentCharges = state.getOrEmpty(RespawnAnchorBlock.CHARGES).orElse(0);
        if (currentCharges < (int) Math.round(charges.getValue())) {
            phase = Phase.Charge;
            chargeQueued = InvHelper.findInHotbar(Items.GLOWSTONE) != -1;
            return;
        }

        phase = Phase.Explode;
        explodeQueued = findDetonatorSlot(mc) != -1 || hasValidDetonatorHand(mc);
    }

    @EventHandler
    private void onInteract(EventInteract event) {
        if (event.getMode() != InteractionMode.NCP || anchorPos == null) return;

        if (placeQueued) {
            queuePlace(event);
            return;
        }

        if (chargeQueued) {
            queueCharge(event);
            return;
        }

        if (explodeQueued) {
            queueExplode(event);
        }
    }

    @EventHandler
    private void onShader(EventShader event) {
        if (!render.getValue() || !useShader.getValue()) return;

        if (target != null) event.prepare(targetColor.getValue().color);
        if (breakPos != null) {
            event.prepare(cityColor.getValue().color);
            event.prepare(anchorColor.getValue().color);
        }
    }

    @EventHandler
    private void onWorldRender(EventWorldRender event) {
        if (!render.getValue()) return;

        WorldDrawer.start();
        float pulse = pulse();

        if (target != null) {
            Box targetBox = target.getBoundingBox().expand(0.02 + pulse * 0.015);
            WorldDrawer.dynamicBoxSides(targetColor.getValue(), useShader.getValue(), targetBox, 0.0f);
            WorldDrawer.boxLines(targetColor.getValue(), targetBox.expand(0.01));
        }

        if (breakPos != null) {
            ColorOption.Value color = switch (phase) {
                case City -> cityColor.getValue();
                case Place, Charge, Explode -> anchorColor.getValue();
                case Blocked, Searching -> cityColor.getValue();
            };

            Box main = new Box(breakPos).expand(0.015 + pulse * 0.035);
            Box outline = new Box(breakPos).expand(0.04 + pulse * 0.02);
            WorldDrawer.dynamicBoxSides(color, useShader.getValue(), main, phase == Phase.City ? 0.35f : 0.0f);
            WorldDrawer.boxLines(color, outline);

            if (phase == Phase.Charge || phase == Phase.Explode) {
                double inset = phase == Phase.Explode ? 0.20 : 0.28;
                Box core = new Box(
                    breakPos.getX() + inset,
                    breakPos.getY() + inset,
                    breakPos.getZ() + inset,
                    breakPos.getX() + 1.0 - inset,
                    breakPos.getY() + 1.0 - inset,
                    breakPos.getZ() + 1.0 - inset
                );
                WorldDrawer.dynamicBoxSides(anchorColor.getValue(), useShader.getValue(), core, 0.0f);
                WorldDrawer.boxLines(anchorColor.getValue(), core.expand(0.015));
            }
        }

        WorldDrawer.draw(event.matrices);
    }

    private void queuePlace(EventInteract event) {
        int anchorSlot = InvHelper.findInHotbar(Items.RESPAWN_ANCHOR);
        if (anchorSlot == -1) return;

        BlockHitResult hitResult = PlaceHelper.cast(anchorPos, airPlace.getValue(), InteractionMode.NCP, breakRange.getValue(), breakRange.getValue());
        if (hitResult == null) return;

        final int slot = anchorSlot;
        float[] rotationValues = MathHelper.calculateRotation(hitResult.getPos(), rotate.getValue());
        Runnable action = () -> {
            SwapContext swap = resolveSwap(slot);
            if (!swap.allowed) return;

            if (swap.slot != -1) InvHelper.swapToSlot(swap.slot, swap.swapType);
            PlaceHelper.place(InteractionMode.NCP, hitResult, Hand.MAIN_HAND);
            if (swap.swapBack) InvHelper.swapBack();

            ColorOption.Value color = anchorColor.getValue();
            PlaceRenderer.addPlacement(new PlaceRenderer.PlacementRecord(
                PlaceRenderer.getRenderPos(hitResult),
                System.currentTimeMillis(),
                850L,
                color.color,
                color.fillOpacity,
                color.outlineOpacity,
                0.25f,
                0.18f,
                0.15f,
                useShader.getValue()
            ));

            interactTimer = 0;
            placeQueued = false;
        };

        event.addInteraction(new Interaction(action, rotate.getValue(), rotationValues[0], rotationValues[1]));
    }

    private void queueCharge(EventInteract event) {
        int glowstoneSlot = InvHelper.findInHotbar(Items.GLOWSTONE);
        if (glowstoneSlot == -1) return;

        Vec3d hitPos = anchorPos.toCenterPos();
        BlockHitResult hitResult = new BlockHitResult(hitPos, Direction.UP, anchorPos, false);
        final int slot = glowstoneSlot;

        float[] rotationValues = MathHelper.calculateRotation(hitPos, rotate.getValue());
        Runnable action = () -> {
            SwapContext swap = resolveSwap(slot);
            if (!swap.allowed) return;

            if (swap.slot != -1) InvHelper.swapToSlot(swap.slot, swap.swapType);
            MinecraftClient mc = MinecraftClient.getInstance();
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hitResult);
            mc.player.swingHand(Hand.MAIN_HAND);
            if (swap.swapBack) InvHelper.swapBack();

            interactTimer = 0;
            chargeQueued = false;
        };

        event.addInteraction(new Interaction(action, rotate.getValue(), rotationValues[0], rotationValues[1]));
    }

    private void queueExplode(EventInteract event) {
        MinecraftClient mc = MinecraftClient.getInstance();
        UseContext context = resolveDetonatorContext(mc);
        if (context == null) return;

        Vec3d hitPos = anchorPos.toCenterPos();
        BlockHitResult hitResult = new BlockHitResult(hitPos, Direction.UP, anchorPos, false);

        float[] rotationValues = MathHelper.calculateRotation(hitPos, rotate.getValue());
        Runnable action = () -> {
            if (context.slot != -1) InvHelper.swapToSlot(context.slot, context.swapType);
            mc.interactionManager.interactBlock(mc.player, context.hand, hitResult);
            mc.player.swingHand(context.hand);
            if (context.swapBack) InvHelper.swapBack();

            interactTimer = 0;
            explodeQueued = false;
        };

        event.addInteraction(new Interaction(action, rotate.getValue(), rotationValues[0], rotationValues[1]));
    }

    private void mineBlock(MinecraftClient mc, BlockPos pos) {
        if (distanceSq(mc, pos.toCenterPos()) > breakRange.getValue() * breakRange.getValue()) return;
        if (!WorldHelper.canBreak(pos)) return;

        Direction direction = Direction.UP;
        mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.START_DESTROY_BLOCK, pos, direction));
        mc.interactionManager.updateBlockBreakingProgress(pos, direction);
        mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK, pos, direction));
        mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
    }

    private PlayerEntity findTarget(MinecraftClient mc) {
        PlayerEntity best = null;
        double bestDistance = Double.MAX_VALUE;

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player || !player.isAlive()) continue;
            if (FriendManager.isFriend(player.getName().getString())) continue;

            double distance = player.squaredDistanceTo(mc.player);
            if (distance > targetRange.getValue() * targetRange.getValue()) continue;

            if (distance < bestDistance) {
                best = player;
                bestDistance = distance;
            }
        }

        return best;
    }

    private BlockPos findCityPos(MinecraftClient mc, PlayerEntity target) {
        BlockPos base = target.getBlockPos();
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;

        for (Direction direction : Direction.Type.HORIZONTAL) {
            BlockPos pos = base.offset(direction);
            BlockState state = mc.world.getBlockState(pos);

            if (!isSurroundBlock(state)) continue;
            if (!WorldHelper.canBreak(pos)) continue;
            if (distanceSq(mc, pos.toCenterPos()) > breakRange.getValue() * breakRange.getValue()) continue;

            double score = distanceSq(mc, pos.toCenterPos());
            if (score < bestScore) {
                best = pos.toImmutable();
                bestScore = score;
            }
        }

        return best;
    }

    private boolean isTrackedPosValid(PlayerEntity target, BlockPos pos) {
        BlockPos base = target.getBlockPos();
        for (Direction direction : Direction.Type.HORIZONTAL) {
            if (base.offset(direction).equals(pos)) return true;
        }

        return false;
    }

    private boolean isSurroundBlock(BlockState state) {
        Block block = state.getBlock();
        if (state.isAir() || state.isReplaceable()) return false;

        return block == Blocks.OBSIDIAN
            || block == Blocks.CRYING_OBSIDIAN
            || block == Blocks.ENDER_CHEST
            || block == Blocks.ANCIENT_DEBRIS
            || block == Blocks.NETHERITE_BLOCK;
    }

    private UseContext resolveDetonatorContext(MinecraftClient mc) {
        if (isValidDetonator(mc.player.getOffHandStack())) return new UseContext(Hand.OFF_HAND, -1, SwapType.Normal, false);
        if (isValidDetonator(mc.player.getMainHandStack())) return new UseContext(Hand.MAIN_HAND, -1, SwapType.Normal, false);

        int slot = findDetonatorSlot(mc);
        if (slot == -1) return null;
        return new UseContext(Hand.MAIN_HAND, slot, silentSwitch.getValue() ? SwapType.Silent : SwapType.Normal, silentSwitch.getValue());
    }

    private boolean hasValidDetonatorHand(MinecraftClient mc) {
        return isValidDetonator(mc.player.getMainHandStack()) || isValidDetonator(mc.player.getOffHandStack());
    }

    private int findDetonatorSlot(MinecraftClient mc) {
        return InvHelper.findInHotbar(stack -> isValidDetonator(stack) && stack != mc.player.getMainHandStack());
    }

    private boolean isValidDetonator(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return true;
        return !stack.isOf(Items.GLOWSTONE) && !stack.isOf(Items.RESPAWN_ANCHOR);
    }

    private SwapContext resolveSwap(int slot) {
        return new SwapContext(true, slot, silentSwitch.getValue() ? SwapType.Silent : SwapType.Normal, silentSwitch.getValue());
    }

    private double distanceSq(MinecraftClient mc, Vec3d pos) {
        double dx = mc.player.getX() - pos.x;
        double dy = mc.player.getEyeY() - pos.y;
        double dz = mc.player.getZ() - pos.z;
        return dx * dx + dy * dy + dz * dz;
    }

    private float pulse() {
        return (float) ((java.lang.Math.sin(System.currentTimeMillis() / 170.0) + 1.0) * 0.5);
    }

    private void resetState() {
        target = null;
        warnedAboutDimension = false;
        resetTrackedBlocks();
    }

    private void resetTrackedBlocks() {
        breakPos = null;
        anchorPos = null;
        phase = Phase.Searching;
        breakTimer = 0;
        interactTimer = 0;
        placeQueued = false;
        chargeQueued = false;
        explodeQueued = false;
    }

    @Override
    public String getArrayListInfo() {
        if (target == null) return null;
        return target.getName().getString() + " " + phase.name();
    }

    private enum Phase {
        Searching,
        City,
        Place,
        Charge,
        Explode,
        Blocked
    }

    private record UseContext(Hand hand, int slot, SwapType swapType, boolean swapBack) {
    }

    private record SwapContext(boolean allowed, int slot, SwapType swapType, boolean swapBack) {
    }
}
