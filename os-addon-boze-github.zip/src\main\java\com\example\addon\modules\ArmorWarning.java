package com.example.addon.modules;

import dev.boze.api.addon.AddonModule;
import dev.boze.api.event.EventPlayerUpdate;
import dev.boze.api.option.SliderOption;
import dev.boze.api.option.ToggleOption;
import dev.boze.api.utility.ChatHelper;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;

public class ArmorWarning extends AddonModule {
    public static final ArmorWarning INSTANCE = new ArmorWarning();

    public final SliderOption threshold = new SliderOption(this, "Threshold", "Durability percentage that triggers the warning.", 25.0, 1.0, 100.0, 1.0);
    public final ToggleOption ignoreUnbreakable = new ToggleOption(this, "IgnoreUnbreakable", "Ignore armor pieces that cannot take damage.", true);

    private boolean warned;

    private ArmorWarning() {
        super("ArmorWarning", "Warns when your armor drops below a durability threshold.");
    }

    @Override
    public void onEnable() {
        warned = false;
    }

    @EventHandler
    private void onPlayerUpdate(EventPlayerUpdate event) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;

        boolean low = isLow(mc.player.getEquippedStack(EquipmentSlot.HEAD))
            || isLow(mc.player.getEquippedStack(EquipmentSlot.CHEST))
            || isLow(mc.player.getEquippedStack(EquipmentSlot.LEGS))
            || isLow(mc.player.getEquippedStack(EquipmentSlot.FEET));

        if (low && !warned) {
            ChatHelper.sendMsg("armor-warning", "Ton armure est presque cassée !");
            warned = true;
        } else if (!low) {
            warned = false;
        }
    }

    private boolean isLow(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        if (!stack.isDamageable()) return !ignoreUnbreakable.getValue();

        int max = stack.getMaxDamage();
        int remaining = max - stack.getDamage();
        double percent = (remaining * 100.0) / Math.max(1, max);
        return percent <= threshold.getValue();
    }

    @Override
    public String getArrayListInfo() {
        return Math.round(threshold.getValue()) + "%";
    }
}
