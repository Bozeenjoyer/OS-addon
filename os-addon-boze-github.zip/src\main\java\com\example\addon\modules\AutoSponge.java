package com.example.addon.modules;

import dev.boze.api.addon.AddonModule;
import dev.boze.api.client.FriendManager;
import dev.boze.api.event.EventInteract;
import dev.boze.api.event.EventPlayerUpdate;
import dev.boze.api.event.EventShader;
import dev.boze.api.event.EventWorldRender;
import dev.boze.api.option.ColorOption;
import dev.boze.api.option.SliderOption;
import dev.boze.api.option.ToggleOption;
import dev.boze.api.render.ColorMaker;
import dev.boze.api.render.PlaceRenderer;
import dev.boze.api.render.WorldDrawer;
import dev.boze.api.utility.MathHelper;
import dev.boze.api.utility.interaction.Interaction;
import dev.boze.api.utility.interaction.InteractionMode;
import dev.boze.api.utility.interaction.InvHelper;
import dev.boze.api.utility.interaction.PlaceHelper;
import dev.boze.api.utility.interaction.SwapType;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;

public class AutoSponge extends AddonModule {
    public static final AutoSponge INSTANCE = new AutoSponge();

    public final SliderOption targetRange = new SliderOption(this, "TargetRange", "How far away the target can be.", 6.0, 0.0, 12.0, 0.1);
    public final SliderOption placeRange = new SliderOption(this, "PlaceRange", "How far away the sponge can be placed.", 5.0, 0.0, 6.0, 0.1);
    public final SliderOption delay = new SliderOption(this, "Delay", "Ticks between placements.", 1.0, 0.0, 10.0, 1.0);
    public final ToggleOption rotate = new ToggleOption(this, "Rotate", "Rotate when placing.", true);
    public final ToggleOption airPlace = new ToggleOption(this, "AirPlace", "Allow placements without support.", true);
    public final ToggleOption pauseOnEat = new ToggleOption(this, "PauseOnEat", "Pause while using items.", true);
    public final ToggleOption render = new ToggleOption(this, "Render", "Render the current target and placement.", true);
    public final ToggleOption useShader = new ToggleOption(this, "UseShader", "Use Boze shader rendering.", true, render);
    public final ColorOption targetColor = new ColorOption(this, "TargetColor", "Color of the target box.", ColorMaker.staticColor(50, 180, 255), 0.08f, 1.0f, render::getValue);
    public final ColorOption placeColor = new ColorOption(this, "PlaceColor", "Color of the sponge placement.", ColorMaker.staticColor(255, 210, 60), 0.14f, 1.0f, render::getValue);

    private PlayerEntity target;
    private BlockPos placePos;
    private int timer;
    private boolean placeQueued;

    private AutoSponge() {
        super("AutoSponge", "Targets players and airplaces sponges into nearby water.");
    }

    @Override
    public void onEnable() {
        target = null;
        placePos = null;
        timer = 0;
        placeQueued = false;
    }

    @EventHandler
    private void onPlayerUpdate(EventPlayerUpdate event) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        if (pauseOnEat.getValue() && mc.player.isUsingItem()) {
            placeQueued = false;
            return;
        }

        target = findTarget(mc);
        if (target == null) {
            placePos = null;
            timer = 0;
            placeQueued = false;
            return;
        }

        placePos = findBestSpongePos(mc, target);
        if (placePos == null) {
            placeQueued = false;
            return;
        }

        if (timer < (int) Math.round(delay.getValue())) {
            timer++;
            placeQueued = false;
            return;
        }

        placeQueued = true;
    }

    @EventHandler
    private void onInteract(EventInteract event) {
        if (!placeQueued || placePos == null) return;

        int spongeSlot = InvHelper.findInHotbar(Blocks.SPONGE);
        if (spongeSlot == -1) spongeSlot = InvHelper.findInHotbar(Blocks.WET_SPONGE);
        if (spongeSlot == -1) return;
        final int slot = spongeSlot;
        InteractionMode mode = event.getMode();

        BlockHitResult cast = PlaceHelper.cast(placePos, airPlace.getValue(), mode, placeRange.getValue(), placeRange.getValue());
        if (cast == null && airPlace.getValue()) {
            cast = new BlockHitResult(placePos.toCenterPos(), Direction.UP, placePos, false);
        }
        if (cast == null) return;
        final BlockHitResult hitResult = cast;

        float[] rotation = MathHelper.calculateRotation(hitResult.getPos(), rotate.getValue());
        Runnable place = () -> {
            InvHelper.swapToSlot(slot, SwapType.Silent);

            boolean placed = PlaceHelper.place(mode, hitResult, Hand.MAIN_HAND);
            MinecraftClient mc = MinecraftClient.getInstance();
            if (!placed && mc.player != null && mc.interactionManager != null) {
                mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hitResult);
            }

            InvHelper.swapBack();

            if (render.getValue()) {
                ColorOption.Value color = placeColor.getValue();
                PlaceRenderer.addPlacement(new PlaceRenderer.PlacementRecord(
                    PlaceRenderer.getRenderPos(hitResult),
                    System.currentTimeMillis(),
                    900L,
                    color.color,
                    color.fillOpacity,
                    color.outlineOpacity,
                    0.10f,
                    0.10f,
                    0.10f,
                    useShader.getValue()
                ));
            }

            timer = 0;
            placeQueued = false;
        };

        event.addInteraction(new Interaction(place, rotate.getValue(), rotation[0], rotation[1]));
    }

    @EventHandler
    private void onShader(EventShader event) {
        if (!render.getValue() || !useShader.getValue()) return;
        if (target != null) event.prepare(targetColor.getValue().color);
        if (placePos != null) event.prepare(placeColor.getValue().color);
    }

    @EventHandler
    private void onWorldRender(EventWorldRender event) {
        if (!render.getValue()) return;

        WorldDrawer.start();

        if (target != null) {
            WorldDrawer.dynamicBox(targetColor.getValue(), useShader.getValue(), target.getBoundingBox());
        }

        if (placePos != null) {
            WorldDrawer.dynamicBox(placeColor.getValue(), useShader.getValue(), new Box(placePos));
            WorldDrawer.boxLines(placeColor.getValue(), new Box(placePos).expand(0.03));
        }

        WorldDrawer.draw(event.matrices);
    }

    private PlayerEntity findTarget(MinecraftClient mc) {
        PlayerEntity best = null;
        double bestDistance = Double.MAX_VALUE;

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player || !player.isAlive()) continue;
            if (FriendManager.isFriend(player.getName().getString())) continue;

            double distance = player.squaredDistanceTo(mc.player);
            if (distance > targetRange.getValue() * targetRange.getValue()) continue;

            if (distance < bestDistance) {
                best = player;
                bestDistance = distance;
            }
        }

        return best;
    }

    private BlockPos findBestSpongePos(MinecraftClient mc, PlayerEntity player) {
        BlockPos center = player.getBlockPos();
        BlockPos best = null;
        int bestWater = 0;
        double bestDist = Double.MAX_VALUE;

        for (int x = -2; x <= 2; x++) {
            for (int y = -1; y <= 2; y++) {
                for (int z = -2; z <= 2; z++) {
                    BlockPos pos = center.add(x, y, z);
                    BlockState state = mc.world.getBlockState(pos);

                    if (!state.isReplaceable() && !state.isOf(Blocks.WATER)) continue;
                    if (mc.player.squaredDistanceTo(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5) > placeRange.getValue() * placeRange.getValue()) continue;

                    int waterScore = countNearbyWater(mc, pos);
                    if (waterScore <= 0) continue;

                    double distance = mc.player.getEyePos().squaredDistanceTo(pos.toCenterPos());
                    if (waterScore > bestWater || (waterScore == bestWater && distance < bestDist)) {
                        best = pos.toImmutable();
                        bestWater = waterScore;
                        bestDist = distance;
                    }
                }
            }
        }

        return best;
    }

    private int countNearbyWater(MinecraftClient mc, BlockPos pos) {
        int count = isWater(mc, pos) ? 2 : 0;
        for (Direction direction : Direction.values()) {
            if (isWater(mc, pos.offset(direction))) count++;
        }
        return count;
    }

    private boolean isWater(MinecraftClient mc, BlockPos pos) {
        return mc.world.getFluidState(pos).isIn(FluidTags.WATER) || mc.world.getBlockState(pos).isOf(Blocks.WATER);
    }

    @Override
    public String getArrayListInfo() {
        return target != null ? target.getName().getString() : null;
    }
}
