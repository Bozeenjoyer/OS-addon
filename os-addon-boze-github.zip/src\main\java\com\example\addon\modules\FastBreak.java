package com.example.addon.modules;

import dev.boze.api.addon.AddonModule;
import dev.boze.api.event.EventPlayerUpdate;
import dev.boze.api.event.EventWorldRender;
import dev.boze.api.option.ColorOption;
import dev.boze.api.option.SliderOption;
import dev.boze.api.option.ToggleOption;
import dev.boze.api.render.ColorMaker;
import dev.boze.api.render.WorldDrawer;
import dev.boze.api.utility.WorldHelper;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;

public class FastBreak extends AddonModule {
    public static final FastBreak INSTANCE = new FastBreak();

    public final SliderOption delay = new SliderOption(this, "Delay", "Ticks between fast-break attempts.", 0.0, 0.0, 20.0, 1.0);
    public final SliderOption attempts = new SliderOption(this, "Attempts", "How many stop packets to send each cycle.", 4.0, 1.0, 10.0, 1.0);
    public final SliderOption cycles = new SliderOption(this, "Cycles", "How many start/stop cycles to send per attempt.", 2.0, 1.0, 6.0, 1.0);
    public final ToggleOption onlyPick = new ToggleOption(this, "OnlyPick", "Only fast-break while holding a pickaxe.", true);
    public final ToggleOption persist = new ToggleOption(this, "Persist", "Continue rebreaking the tracked block after releasing attack.", true);
    public final ToggleOption render = new ToggleOption(this, "Render", "Render the tracked block.", true);
    public final ColorOption blockColor = new ColorOption(this, "BlockColor", "Color of the tracked block render.", ColorMaker.staticColor(204, 0, 0), 0.10f, 1.0f, render::getValue);

    private BlockPos trackedPos;
    private Direction trackedSide = Direction.UP;
    private int ticks;
    private boolean attackHeld;

    private FastBreak() {
        super("FastBreak", "Rapidly re-sends break packets for the tracked block.");
    }

    @Override
    public void onEnable() {
        trackedPos = null;
        trackedSide = Direction.UP;
        ticks = 0;
        attackHeld = false;
    }

    @EventHandler
    private void onPlayerUpdate(EventPlayerUpdate event) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.getNetworkHandler() == null) return;

        boolean attackPressed = mc.options.attackKey.isPressed();
        if (attackPressed && mc.crosshairTarget instanceof BlockHitResult hitResult) {
            trackedPos = hitResult.getBlockPos().toImmutable();
            trackedSide = hitResult.getSide();
            if (!attackHeld) ticks = (int) Math.round(delay.getValue());
        }
        attackHeld = attackPressed;

        if (trackedPos == null) return;
        if (!WorldHelper.canBreak(trackedPos) || (!attackPressed && !persist.getValue())) {
            trackedPos = null;
            return;
        }

        if (!shouldMine()) return;

        if (ticks < (int) Math.round(delay.getValue())) {
            ticks++;
            return;
        }

        ticks = 0;
        sendPackets(mc);
    }

    private void sendPackets(MinecraftClient mc) {
        int totalCycles = (int) Math.round(cycles.getValue());
        int totalAttempts = (int) Math.round(attempts.getValue());

        for (int cycle = 0; cycle < totalCycles; cycle++) {
            mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.START_DESTROY_BLOCK, trackedPos, trackedSide));
            for (int i = 0; i < totalAttempts; i++) {
                mc.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK, trackedPos, trackedSide));
            }
        }

        mc.getNetworkHandler().sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
    }

    private boolean shouldMine() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || trackedPos == null) return false;
        return !onlyPick.getValue() || mc.player.getMainHandStack().isIn(ItemTags.PICKAXES);
    }

    @EventHandler
    private void onWorldRender(EventWorldRender event) {
        if (!render.getValue() || trackedPos == null) return;

        WorldDrawer.start();
        WorldDrawer.box(blockColor.getValue(), new Box(trackedPos));
        WorldDrawer.draw(event.matrices);
    }

    @Override
    public String getArrayListInfo() {
        if (trackedPos == null) return null;
        return trackedPos.getX() + ", " + trackedPos.getY() + ", " + trackedPos.getZ();
    }
}
