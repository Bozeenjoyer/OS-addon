package com.example.addon.modules;

import dev.boze.api.addon.AddonModule;
import dev.boze.api.client.FriendManager;
import dev.boze.api.event.EventInteract;
import dev.boze.api.event.EventPlayerUpdate;
import dev.boze.api.event.EventShader;
import dev.boze.api.event.EventWorldRender;
import dev.boze.api.option.ColorOption;
import dev.boze.api.option.SliderOption;
import dev.boze.api.option.ToggleOption;
import dev.boze.api.render.ColorMaker;
import dev.boze.api.render.PlaceRenderer;
import dev.boze.api.render.WorldDrawer;
import dev.boze.api.utility.MathHelper;
import dev.boze.api.utility.WorldHelper;
import dev.boze.api.utility.interaction.Interaction;
import dev.boze.api.utility.interaction.InteractionMode;
import dev.boze.api.utility.interaction.InvHelper;
import dev.boze.api.utility.interaction.PlaceHelper;
import dev.boze.api.utility.interaction.SwapType;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.FireChargeItem;
import net.minecraft.item.FlintAndSteelItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

public class TNTAura extends AddonModule {
    public static final TNTAura INSTANCE = new TNTAura();

    public final SliderOption targetRange = new SliderOption(this, "TargetRange", "How far away targets can be.", 6.0, 0.0, 10.0, 0.1);
    public final SliderOption placeRange = new SliderOption(this, "PlaceRange", "How far away TNT can be placed.", 5.0, 0.0, 6.0, 0.1);
    public final SliderOption placeDelay = new SliderOption(this, "PlaceDelay", "Ticks between TNT placements.", 1.0, 0.0, 20.0, 1.0);
    public final SliderOption igniteDelay = new SliderOption(this, "IgniteDelay", "Ticks between ignition attempts.", 1.0, 0.0, 20.0, 1.0);
    public final ToggleOption rotate = new ToggleOption(this, "Rotate", "Rotate before placing and igniting.", true);
    public final ToggleOption pauseOnEat = new ToggleOption(this, "PauseOnEat", "Pause while using an item.", true);
    public final ToggleOption airPlace = new ToggleOption(this, "AirPlace", "Allow TNT placement without direct support.", true);
    public final ToggleOption silentSwitch = new ToggleOption(this, "SilentSwitch", "Use silent item swapping.", true);
    public final ToggleOption useFireCharge = new ToggleOption(this, "UseFireCharge", "Allow fire charges for ignition.", true);
    public final ToggleOption igniteExisting = new ToggleOption(this, "IgniteExisting", "Ignite already-placed TNT near the target.", true);
    public final ToggleOption render = new ToggleOption(this, "Render", "Render the current target and TNT spots.", true);
    public final ToggleOption useShader = new ToggleOption(this, "UseShader", "Use Boze shader rendering.", true, render);
    public final ColorOption targetColor = new ColorOption(this, "TargetColor", "Color of the target box.", ColorMaker.staticColor(255, 90, 90), 0.08f, 1.0f, render::getValue);
    public final ColorOption placeColor = new ColorOption(this, "PlaceColor", "Color of the TNT placement.", ColorMaker.staticColor(255, 130, 60), 0.14f, 1.0f, render::getValue);

    private PlayerEntity target;
    private BlockPos placePos;
    private BlockPos ignitePos;
    private boolean placeQueued;
    private boolean igniteQueued;
    private int placeTimer;
    private int igniteTimer;

    private TNTAura() {
        super("TNTAura", "Places and ignites TNT around nearby targets.");
    }

    @Override
    public void onEnable() {
        target = null;
        placePos = null;
        ignitePos = null;
        placeQueued = false;
        igniteQueued = false;
        placeTimer = 0;
        igniteTimer = 0;
    }

    @EventHandler
    private void onPlayerUpdate(EventPlayerUpdate event) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (pauseOnEat.getValue() && mc.player.isUsingItem()) {
            placeQueued = false;
            igniteQueued = false;
            return;
        }

        target = findTarget(mc);
        placePos = target != null ? findBestPlacePos(mc, target) : null;
        ignitePos = target != null ? findIgnitePos(mc, target) : null;

        if (placeTimer < (int) Math.round(placeDelay.getValue())) placeTimer++;
        if (igniteTimer < (int) Math.round(igniteDelay.getValue())) igniteTimer++;

        placeQueued = placePos != null && placeTimer >= (int) Math.round(placeDelay.getValue());
        igniteQueued = ignitePos != null && igniteTimer >= (int) Math.round(igniteDelay.getValue()) && hasIgniter();
    }

    @EventHandler
    private void onInteract(EventInteract event) {
        if (igniteQueued && ignitePos != null) {
            queueIgnite(event);
            return;
        }

        if (placeQueued && placePos != null) {
            queuePlacement(event);
        }
    }

    @EventHandler
    private void onShader(EventShader event) {
        if (!render.getValue() || !useShader.getValue()) return;
        if (target != null) event.prepare(targetColor.getValue().color);
        if (placePos != null || ignitePos != null) event.prepare(placeColor.getValue().color);
    }

    @EventHandler
    private void onWorldRender(EventWorldRender event) {
        if (!render.getValue()) return;

        WorldDrawer.start();
        float pulse = pulse();

        if (target != null) {
            Box targetBox = target.getBoundingBox().expand(0.02 + pulse * 0.015);
            WorldDrawer.dynamicBoxSides(targetColor.getValue(), useShader.getValue(), targetBox, 0.0f);
            WorldDrawer.boxLines(targetColor.getValue(), targetBox.expand(0.01));
        }

        if (placePos != null) {
            Box tntBox = new Box(placePos).expand(0.015 + pulse * 0.04);
            WorldDrawer.dynamicBoxSides(placeColor.getValue(), useShader.getValue(), tntBox, 0.25f);
            WorldDrawer.boxLines(placeColor.getValue(), tntBox.expand(0.015));
        }

        if (ignitePos != null && !ignitePos.equals(placePos)) {
            Box igniteBox = new Box(ignitePos).expand(0.08 + pulse * 0.025);
            WorldDrawer.dynamicBoxSides(placeColor.getValue(), useShader.getValue(), igniteBox, 0.0f);
            WorldDrawer.boxLines(placeColor.getValue(), igniteBox);
        }

        WorldDrawer.draw(event.matrices);
    }

    private void queuePlacement(EventInteract event) {
        int tntSlot = InvHelper.findInHotbar(Blocks.TNT);
        if (tntSlot == -1) return;

        InteractionMode mode = event.getMode();
        BlockHitResult hitResult = PlaceHelper.cast(placePos, airPlace.getValue(), mode, placeRange.getValue(), placeRange.getValue());
        if (hitResult == null) return;

        final int slot = tntSlot;
        float[] rotationValues = MathHelper.calculateRotation(hitResult.getPos(), rotate.getValue());
        Runnable action = () -> {
            SwapContext swap = resolveSwap(slot);
            if (!swap.allowed) return;

            if (swap.slot != -1) {
                InvHelper.swapToSlot(swap.slot, swap.swapType);
            }

            PlaceHelper.place(mode, hitResult, Hand.MAIN_HAND);

            if (render.getValue()) {
                ColorOption.Value color = placeColor.getValue();
                PlaceRenderer.addPlacement(new PlaceRenderer.PlacementRecord(
                    PlaceRenderer.getRenderPos(hitResult),
                    System.currentTimeMillis(),
                    900L,
                    color.color,
                    color.fillOpacity,
                    color.outlineOpacity,
                    0.10f,
                    0.10f,
                    0.10f,
                    useShader.getValue()
                ));
            }

            if (swap.swapBack) InvHelper.swapBack();

            placeTimer = 0;
            placeQueued = false;
        };

        event.addInteraction(new Interaction(action, rotate.getValue(), rotationValues[0], rotationValues[1]));
    }

    private void queueIgnite(EventInteract event) {
        MinecraftClient mc = MinecraftClient.getInstance();
        UseContext context = resolveIgniterContext(mc);
        if (context == null) return;

        Vec3d visiblePoint = WorldHelper.findVisiblePointOnBlock(ignitePos, new Vec3d(mc.player.getX(), mc.player.getEyeY(), mc.player.getZ()));
        Vec3d hitPos = visiblePoint != null ? visiblePoint : ignitePos.toCenterPos();
        BlockHitResult hitResult = new BlockHitResult(hitPos, Direction.UP, ignitePos, false);

        float[] rotationValues = MathHelper.calculateRotation(hitPos, rotate.getValue());
        Runnable action = () -> {
            if (context.slot != -1) {
                InvHelper.swapToSlot(context.slot, context.swapType);
            }

            mc.interactionManager.interactBlock(mc.player, context.hand, hitResult);
            mc.player.swingHand(context.hand);

            if (context.swapBack) InvHelper.swapBack();

            igniteTimer = 0;
            igniteQueued = false;
        };

        event.addInteraction(new Interaction(action, rotate.getValue(), rotationValues[0], rotationValues[1]));
    }

    private PlayerEntity findTarget(MinecraftClient mc) {
        PlayerEntity best = null;
        double bestDistance = Double.MAX_VALUE;

        for (PlayerEntity player : mc.world.getPlayers()) {
            if (player == mc.player || !player.isAlive()) continue;
            if (FriendManager.isFriend(player.getName().getString())) continue;

            double distance = player.squaredDistanceTo(mc.player);
            if (distance > targetRange.getValue() * targetRange.getValue()) continue;

            if (distance < bestDistance) {
                best = player;
                bestDistance = distance;
            }
        }

        return best;
    }

    private BlockPos findBestPlacePos(MinecraftClient mc, PlayerEntity target) {
        BlockPos base = target.getBlockPos();
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;

        for (int x = -1; x <= 1; x++) {
            for (int y = 0; y <= 2; y++) {
                for (int z = -1; z <= 1; z++) {
                    BlockPos pos = base.add(x, y, z);
                    if (!canPlaceTnt(mc, pos)) continue;
                    if (distanceSq(mc, pos.toCenterPos()) > placeRange.getValue() * placeRange.getValue()) continue;

                    double score = pos.toCenterPos().squaredDistanceTo(target.getEyePos());
                    if (score < bestScore) {
                        best = pos.toImmutable();
                        bestScore = score;
                    }
                }
            }
        }

        return best;
    }

    private boolean canPlaceTnt(MinecraftClient mc, BlockPos pos) {
        if (mc.world.getBlockState(pos).isOf(Blocks.TNT)) return true;
        if (!mc.world.getBlockState(pos).isReplaceable()) return false;
        if (!airPlace.getValue() && !WorldHelper.canPlaceAt(pos)) return false;

        Box box = new Box(pos);
        for (PlayerEntity player : mc.world.getPlayers()) {
            if (!player.isSpectator() && player.getBoundingBox().intersects(box)) return false;
        }

        return true;
    }

    private BlockPos findIgnitePos(MinecraftClient mc, PlayerEntity target) {
        BlockPos existing = findExistingTnt(mc, target);
        if (existing != null) return existing;
        if (placePos != null && mc.world.getBlockState(placePos).isOf(Blocks.TNT)) return placePos;
        return null;
    }

    private BlockPos findExistingTnt(MinecraftClient mc, PlayerEntity target) {
        if (!igniteExisting.getValue()) return null;

        BlockPos base = target.getBlockPos();
        BlockPos best = null;
        double bestScore = Double.MAX_VALUE;

        for (int x = -1; x <= 1; x++) {
            for (int y = 0; y <= 2; y++) {
                for (int z = -1; z <= 1; z++) {
                    BlockPos pos = base.add(x, y, z);
                    if (!mc.world.getBlockState(pos).isOf(Blocks.TNT)) continue;
                    if (distanceSq(mc, pos.toCenterPos()) > placeRange.getValue() * placeRange.getValue()) continue;

                    double score = pos.toCenterPos().squaredDistanceTo(target.getEyePos());
                    if (score < bestScore) {
                        best = pos.toImmutable();
                        bestScore = score;
                    }
                }
            }
        }

        return best;
    }

    private boolean hasIgniter() {
        MinecraftClient mc = MinecraftClient.getInstance();
        return isIgniter(mc.player.getMainHandStack())
            || isIgniter(mc.player.getOffHandStack())
            || InvHelper.findInHotbar(this::isIgniter) != -1;
    }

    private UseContext resolveIgniterContext(MinecraftClient mc) {
        if (isIgniter(mc.player.getOffHandStack())) return new UseContext(Hand.OFF_HAND, -1, SwapType.Normal, false);
        if (isIgniter(mc.player.getMainHandStack())) return new UseContext(Hand.MAIN_HAND, -1, SwapType.Normal, false);

        int slot = InvHelper.findInHotbar(this::isIgniter);
        if (slot == -1) return null;

        return new UseContext(Hand.MAIN_HAND, slot, silentSwitch.getValue() ? SwapType.Silent : SwapType.Normal, silentSwitch.getValue());
    }

    private SwapContext resolveSwap(int slot) {
        return new SwapContext(true, slot, silentSwitch.getValue() ? SwapType.Silent : SwapType.Normal, silentSwitch.getValue());
    }

    private boolean isIgniter(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;
        if (stack.getItem() instanceof FlintAndSteelItem) return true;
        return useFireCharge.getValue() && stack.getItem() instanceof FireChargeItem;
    }

    private double distanceSq(MinecraftClient mc, Vec3d pos) {
        double dx = mc.player.getX() - pos.x;
        double dy = mc.player.getEyeY() - pos.y;
        double dz = mc.player.getZ() - pos.z;
        return dx * dx + dy * dy + dz * dz;
    }

    private float pulse() {
        return (float) ((java.lang.Math.sin(System.currentTimeMillis() / 165.0) + 1.0) * 0.5);
    }

    @Override
    public String getArrayListInfo() {
        return target != null ? target.getName().getString() : null;
    }

    private record UseContext(Hand hand, int slot, SwapType swapType, boolean swapBack) {
    }

    private record SwapContext(boolean allowed, int slot, SwapType swapType, boolean swapBack) {
    }
}
