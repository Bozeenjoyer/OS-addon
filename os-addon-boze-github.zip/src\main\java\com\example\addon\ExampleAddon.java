package com.example.addon;

import com.example.addon.modules.ArmorWarning;
import com.example.addon.modules.AnchorCity;
import com.example.addon.modules.AutoSponge;
import com.example.addon.modules.FastBreak;
import com.example.addon.modules.TNTAura;
import dev.boze.api.BozeInstance;
import dev.boze.api.addon.Addon;

public class ExampleAddon extends Addon {
    public static final String ID = "os-addon-boze";
    public static final String NAME = "OS Addon";
    public static final String DESCRIPTION = "OS Addon modules ported to the Boze Addon API";
    public static final String VERSION = "0.1.0";

    public ExampleAddon() {
        super(ID, NAME, DESCRIPTION, VERSION);
    }

    @Override
    public boolean initialize() {
        modules.add(AnchorCity.INSTANCE);
        modules.add(ArmorWarning.INSTANCE);
        modules.add(AutoSponge.INSTANCE);
        modules.add(FastBreak.INSTANCE);
        modules.add(TNTAura.INSTANCE);

        BozeInstance.INSTANCE.registerPackage("com.example.addon");
        return true;
    }
}
